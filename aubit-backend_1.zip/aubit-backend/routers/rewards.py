from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from database import get_db
from auth_utils import get_current_user
import models

router = APIRouter()

REWARD_RATE = 0.005  # 0.5%

class TransactionCreate(BaseModel):
    merchant:   str
    amount_inr: float

class TransactionResponse(BaseModel):
    id:            str
    merchant:      str
    amount_inr:    float
    reward_inr:    float
    reward_gold:   float
    reward_silver: float
    reward_btc:    float
    reward_eth:    float
    status:        str
    created_at:    str

@router.post("/transact", response_model=TransactionResponse, status_code=201)
def log_transaction(
    data: TransactionCreate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if data.amount_inr <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")

    vault = db.query(models.Vault).filter(models.Vault.user_id == current_user.id).first()
    if not vault:
        raise HTTPException(status_code=404, detail="Vault not found — please set up your allocation first")

    reward_total  = round(data.amount_inr * REWARD_RATE, 2)
    r_gold        = round(reward_total * vault.pct_gold   / 100, 4)
    r_silver      = round(reward_total * vault.pct_silver / 100, 4)
    r_btc         = round(reward_total * vault.pct_btc    / 100, 4)
    r_eth         = round(reward_total * vault.pct_eth    / 100, 4)

    # Create transaction record
    txn = models.Transaction(
        user_id       = current_user.id,
        merchant      = data.merchant,
        amount_inr    = data.amount_inr,
        reward_inr    = reward_total,
        reward_gold   = r_gold,
        reward_silver = r_silver,
        reward_btc    = r_btc,
        reward_eth    = r_eth,
        status        = "settled",
    )
    db.add(txn)

    # Update vault balances
    vault.val_gold   += r_gold
    vault.val_silver += r_silver
    vault.val_btc    += r_btc
    vault.val_eth    += r_eth

    db.commit()
    db.refresh(txn)

    return TransactionResponse(
        id=str(txn.id),
        merchant=txn.merchant,
        amount_inr=txn.amount_inr,
        reward_inr=txn.reward_inr,
        reward_gold=txn.reward_gold,
        reward_silver=txn.reward_silver,
        reward_btc=txn.reward_btc,
        reward_eth=txn.reward_eth,
        status=txn.status,
        created_at=str(txn.created_at)
    )

@router.get("/history", response_model=List[TransactionResponse])
def get_history(
    limit: Optional[int] = 20,
    offset: Optional[int] = 0,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    txns = (
        db.query(models.Transaction)
        .filter(models.Transaction.user_id == current_user.id)
        .order_by(models.Transaction.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    return [
        TransactionResponse(
            id=str(t.id), merchant=t.merchant, amount_inr=t.amount_inr,
            reward_inr=t.reward_inr, reward_gold=t.reward_gold,
            reward_silver=t.reward_silver, reward_btc=t.reward_btc,
            reward_eth=t.reward_eth, status=t.status, created_at=str(t.created_at)
        ) for t in txns
    ]

@router.get("/summary")
def get_summary(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    txns = db.query(models.Transaction).filter(models.Transaction.user_id == current_user.id).all()
    total_spent   = sum(t.amount_inr for t in txns)
    total_rewards = sum(t.reward_inr for t in txns)
    return {
        "total_transactions": len(txns),
        "total_spent_inr":    round(total_spent, 2),
        "total_rewards_inr":  round(total_rewards, 2),
        "reward_rate":        "0.5%",
    }
